package tushinsky.alex.simple_calc;

public class Calc {
	
	private double firstNum;
	private double secondNum;
	
	public double getFirstNum() {
		return firstNum;
	}
	public void setFirstNum(double firstNum) {
		this.firstNum = firstNum;
	}
	public double getSecondNum() {
		return secondNum;
	}
	public void setSecondNum(double secondNum) {
		this.secondNum = secondNum;
	}
	
	public String toString() {
		String sOut = "";
		
		sOut += getFirstNum() + " + " + getSecondNum() + " = " + (getFirstNum() + getSecondNum()) + "\n";
		sOut += getFirstNum() + " - " + getSecondNum() + " = " + (getFirstNum() - getSecondNum()) + "\n";
		sOut += getFirstNum() + " * " + getSecondNum() + " = " + (getFirstNum() * getSecondNum()) + "\n";
		sOut += getFirstNum() + " / " + getSecondNum() + " = " + (getFirstNum() / getSecondNum()) + "\n";
		
		return sOut;
	}

}
