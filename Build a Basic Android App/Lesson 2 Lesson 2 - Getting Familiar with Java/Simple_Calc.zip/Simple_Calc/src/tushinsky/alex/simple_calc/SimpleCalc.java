package tushinsky.alex.simple_calc;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class SimpleCalc extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        final TextView txtOut = (TextView) findViewById(R.id.txtOut);
        
        String sOut = "";
        
        Calc oC1 = new Calc();
        oC1.setFirstNum(100);
        oC1.setSecondNum(50);
        sOut += oC1.toString();
        
        sOut += "\n";
        
        Calc oC2 = new Calc();
        oC2.setFirstNum(5678.45);
        oC2.setSecondNum(9933.33);
        sOut += oC2.toString();
        
        
        
        txtOut.setText(sOut);
    }
}