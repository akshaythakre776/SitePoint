package tushinsky.alex.Classes_and_Variables;

import java.text.DecimalFormat;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class ClassesAndVariables extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		final TextView txtOut = (TextView) findViewById(R.id.txtOut);

		Computer oPC = new Computer();
		oPC.setCpu_speed(1200);
		oPC.setHd_size(500);
		oPC.setName("Alex's PC");
		oPC.setRam_size(4);
		oPC.setScreen_res("1920 x 1080");

		Notebook oNote = new Notebook();
		oNote.setCpu_speed(2000);
		oNote.setHd_size(320);
		oNote.setName("My Notebook");
		oNote.setRam_size(2);
		oNote.setScreen_res("1280 x 720");
		oNote.setForm_factor("Tablet PC");
		
		String sOut = "";
		
		//declaring variables
		char capitalC = 'C';
		int iCount = 0;
		short a, b, c;
		a = 10;
		b = 20;
		c = 5;
		
		String sText = "This is a string of text!";
		
		int[] iNums;
		iNums = new int[5];
		
		iNums[0] = 5;
		iNums[1] = 10;
		
		String[] sMessage = {
				"Hello", //0
				" ",     //1
				"world!" //2
		};
		
		//using variables
		sOut += "iCount++ = " + (iCount++) + "\n"; //0, then add 1 to it
		sOut += "++iCount = " + (++iCount) + "\n"; //2
		
		sOut += "iNums[0] + iNums[1] = " + iNums[0] + iNums[1] + "\n";//iNums[0] + iNums[1] = 510
		sOut += "iNums[0] + iNums[1] = " + (iNums[0] + iNums[1]) + "\n";//iNums[0] + iNums[1] = 15
		
		sOut += "a + b / c = " + (a + b / c) + "\n";//14 = 20 / 5 = 4, then 4 + 10 = 14
		sOut += "(a + b) / c = " + ((a + b) / c) + "\n"; //6 = 10 + 20 = 30, then 30 / 5 = 6
		
		//Concatenation
		sOut += sMessage[0] + sMessage[1] + sMessage[2] + "\n";
		
		double dNum = c;
		dNum += 1000.25;
		
		DecimalFormat Curr = new DecimalFormat("$#,###.##");
		sOut += "dNum = " + Curr.format(dNum) + "\n";
		
		String sNum1 = "10";
		String sNum2 = "20";
		
		sOut += "sNum1 + sNum2 = " + sNum1 + sNum2 + "\n"; //sNum1 + sNum2 = 1020;
		sOut += "sNum1 + sNum2 = " + (Integer.parseInt(sNum1) + Integer.parseInt(sNum2)) + "\n"; //30
		
		txtOut.setText(oPC.toString() + "\n" + oNote.toString() + "\n" + sOut);

	}
}