package tushinsky.alex.Classes_and_Variables;

public class Notebook extends Computer {
	
	private String form_factor;

	public String getForm_factor() {
		return form_factor;
	}

	public void setForm_factor(String form_factor) {
		this.form_factor = form_factor;
	}
	
	
	public String toString() {
		String sText = "";
		
		sText += getName() + "\n" +
		         "RAM: " + getRam_size() + "GB\n" +
		         "SPEED: " + getCpu_speed() + "Ghz Processor\n" +
		         "HD Size: " + getHd_size() + "GB\n" +
		         "Form Factor: " + getForm_factor() + "\n" +
		         "Screen Res: " + getScreen_res() + "\n";

		return sText;
	}

}
