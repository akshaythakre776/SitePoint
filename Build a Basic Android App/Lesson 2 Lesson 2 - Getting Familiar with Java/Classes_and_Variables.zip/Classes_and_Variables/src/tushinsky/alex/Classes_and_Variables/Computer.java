package tushinsky.alex.Classes_and_Variables;

public class Computer {
	
	private int cpu_speed;
	private int hd_size;
	private String screen_res;  // 1280 x 720
	private int ram_size;
	private String name;  // Gateway ABC or My Computer
	
	public double getCpu_speed() {
		return (double)cpu_speed / 1000;
	}
	public void setCpu_speed(int cpu_speed) {
		this.cpu_speed = cpu_speed;
	}
	public int getHd_size() {
		return hd_size;
	}
	public void setHd_size(int hd_size) {
		this.hd_size = hd_size;
	}
	public String getScreen_res() {
		return screen_res;
	}
	public void setScreen_res(String screen_res) {
		this.screen_res = screen_res;
	}
	public int getRam_size() {
		return ram_size;
	}
	public void setRam_size(int ram_size) {
		this.ram_size = ram_size;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String toString() {
		String sText = "";
		
		sText += getName() + "\n" +
		         "RAM: " + getRam_size() + "GB\n" +
		         "SPEED: " + getCpu_speed() + "Ghz Processor\n" +
		         "HD Size: " + getHd_size() + "GB\n" +
		         "Screen Res: " + getScreen_res() + "\n";

		return sText;
	}


}
