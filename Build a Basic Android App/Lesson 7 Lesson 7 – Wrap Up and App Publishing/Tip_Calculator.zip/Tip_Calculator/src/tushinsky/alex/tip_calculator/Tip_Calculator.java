package tushinsky.alex.tip_calculator;

import java.text.DecimalFormat;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class Tip_Calculator extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		final TextView txtPCT = (TextView) findViewById(R.id.txtPCT);
		final SeekBar oSeek = (SeekBar) findViewById(R.id.seekBar1);
		oSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				txtPCT.setText(Integer.toString(progress) + "%");
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
			}

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
			}
		});

		final Button btnCalc = (Button) findViewById(R.id.btnCalc);
		btnCalc.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				final EditText txtTotal = (EditText) findViewById(R.id.txtTotal);
				final EditText txtPeople = (EditText) findViewById(R.id.txtPeople);

				float Total = 0;
				int People = 0;
				// validate that txtTotal has a value
				if (txtTotal.getText().length() > 0) {
					Total = Float.parseFloat(txtTotal.getText().toString());
				}
				// validate that txtPeople has a value
				if (txtPeople.getText().length() > 0) {
					People = Integer.parseInt(txtPeople.getText().toString());
				}
				if (People == 0) {
					Toast.makeText(getApplicationContext(),
							"Number of people must be 1 or greater!",
							Toast.LENGTH_SHORT).show();
					return;
				}
				if (Total == 0) {
					Toast.makeText(getApplicationContext(),
							"Total must be greater than 0!", Toast.LENGTH_SHORT)
							.show();
					return;
				}

				final TextView txtOut = (TextView) findViewById(R.id.txtOut);
				int PCT = oSeek.getProgress();
				float Tip = (Total / 100) * PCT;
				float Split = (Total + Tip) / People;
				DecimalFormat Curr = new DecimalFormat("#.##");
				String sText = "Total Bill: $" + Curr.format(Total) + "\n";
				sText += "Tip Amount: $" + Curr.format(Tip) + "\n";
				sText += "Total w/Tip: $" + Curr.format(Total + Tip) + "\n";
				sText += "Split: $" + Curr.format(Split) + "\n";

				txtOut.setText(sText);
			}
		});

	}

}
