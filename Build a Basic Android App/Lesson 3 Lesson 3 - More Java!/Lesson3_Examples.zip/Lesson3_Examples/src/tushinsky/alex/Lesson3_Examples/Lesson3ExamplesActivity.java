package tushinsky.alex.Lesson3_Examples;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class Lesson3ExamplesActivity extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		final TextView tOut = (TextView) findViewById(R.id.txtOut);
		String sOut = "";
		
		
		// String Comparison section
		String sText1 = "Test"; // test, Test, I hate taking tests
		String sText2 = "test";

		if (sText1.contains(sText2)) {
			sOut += "sText1 contains \"" + sText2 + "\"\n";
			sOut += "sText2 starts at char. position: "
					+ sText1.indexOf(sText2) + "\n";
		}

		if (sText1.contentEquals(sText2)) {
			sOut += "Strings are equal!\n";
		}

		if (sText1.equalsIgnoreCase(sText2)) {
			sOut += "Strings are equal regardless of case.\n";
		}

		// ternary operation
		String sLight = "";
		boolean bDrive = (!sLight.equals("red")) ? true : false;

		if (bDrive) {
			sOut += "bDrive = DRIVE!\n";
		} else {
			sOut += "bDrive is false - STOP!\n";
		}

		// for loops, switch statement
		for (int i = 1; i <= 10; i += 2) {

			switch (i) {
			case 1:
				sOut += "i is One!\n";
				break;
			case 2:
				sOut += "i is Two!\n";
				break;
			case 3:
				sOut += "i is Three!\n";
				break;
			case 4:
				sOut += "i is Four!\n";
				break;
			case 5:
				sOut += "i is Five!\n";
				break;
			default:
				sOut += "i is greater than five!\n";
				break;
			}
		}

		int i = 1;
		while (i <= 10) {

			switch (i) {
			case 1:
				sOut += "i is One!\n";
				break;
			case 2:
				sOut += "i is Two!\n";
				break;
			case 3:
				sOut += "i is Three!\n";
				break;
			case 4:
				sOut += "i is Four!\n";
				break;
			case 5:
				sOut += "i is Five!\n";
				break;
			default:
				sOut += "i is greater than five!\n";
				break;
			}
			i += 2;
		}

	
		// methods, for-each loops, and multi-dimensional array
		int[][] inputGrid;

		inputGrid = new int[3][3];

		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 3; col++) {
				inputGrid[row][col] = row + col;
			}
		}

		sOut += GridOutput(inputGrid);

		tOut.setText(sOut);
	}

	String GridOutput(int[][] imGrid) {

		String sText = "-----------------------\n";

		for (int[] row : imGrid) {
			for (int cell : row) {
				sText += " | " + cell + " | ";
			}
			sText += "\n";
		}

		sText += "-----------------------\n";

		return sText;
	}

}