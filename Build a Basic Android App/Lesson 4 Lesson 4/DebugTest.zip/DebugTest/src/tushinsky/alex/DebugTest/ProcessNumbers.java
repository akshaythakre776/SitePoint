package tushinsky.alex.DebugTest;

public class ProcessNumbers {

	private int FirstNum;
	private int SecondNum;

	public int getFirstNum() {
		return FirstNum;
	}

	public void setFirstNum(int firstNum) {
		FirstNum = firstNum;
	}

	public int getSecondNum() {
		return SecondNum;
	}

	public void setSecondNum(int secondNum) {
		SecondNum = secondNum;
	}

	@Override
	public String toString() {
		return FirstNum + " + " + SecondNum + " = " + (FirstNum + FirstNum);
	}

}
