package tushinsky.alex.DebugTest;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class DebugTest extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		final TextView txtOut = (TextView) findViewById(R.id.txtOut);

		int FirstNumber = 2;
		int SecondNumber = 3;

		FirstNumber--;

		SecondNumber += 2;

		SecondNumber = SecondNumber / 0;

		String sOut = "";

		sOut = GetResult(FirstNumber, SecondNumber);

		txtOut.setText(sOut);
	}

	String GetResult(int Num1, int Num2) {
		ProcessNumbers oProc = new ProcessNumbers();
		oProc.setFirstNum(Num1);
		oProc.setSecondNum(Num2);

		return oProc.toString();
	}
}