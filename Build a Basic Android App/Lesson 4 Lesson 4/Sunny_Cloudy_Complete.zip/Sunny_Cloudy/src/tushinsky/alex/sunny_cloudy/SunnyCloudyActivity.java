package tushinsky.alex.sunny_cloudy;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

public class SunnyCloudyActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        final Button btnOK = (Button) findViewById(R.id.btnOK);
        
        btnOK.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				final RadioButton rdCloudy = (RadioButton) findViewById(R.id.rdCloudy);
				final ImageView imgMain = (ImageView) findViewById(R.id.imgMain);
				final TextView txtOut = (TextView) findViewById(R.id.txtOut);
				
				if (rdCloudy.isChecked()) {
					imgMain.setImageResource(R.drawable.cloudy);
					txtOut.setText("It's cloudy, so we're going to class!");
				}
				else {
					imgMain.setImageResource(R.drawable.sunny);
					txtOut.setText("It's sunny, so we're going to the beach!");					
				}
				
			}
		});
        
        
    }
}