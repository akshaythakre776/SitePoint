package tushinsky.alex.lesson4_lifecycle;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class Lesson4LifeCycle extends Activity {
	public static final String DATE_FORMAT = "MM-dd-yyyy HH:mm:ss";
	String sStatus = "";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		SharedPreferences oSettings = getSharedPreferences("screen_msg", 0);
		sStatus = oSettings.getString("screen_msg", "");
		setStatus("onCreate");
	}

	public static String Now() {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
		return sdf.format(cal.getTime());
	}

	void setStatus(String sEvent) {
		if (sEvent.equalsIgnoreCase("onCreate")) {
			sStatus += "============================\n";
		}

		sStatus += "In " + sEvent + "() at: " + Now() + "\n"; // generates
																// "In onStart() at: 10/10/10 10:10am";
		final TextView tOut = (TextView) findViewById(R.id.txtOut);
		tOut.setText(sStatus);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		setStatus("onDestroy");

	}

	@Override
	protected void onPause() {
		super.onPause();
		setStatus("onPause");
	}

	@Override
	protected void onRestart() {
		super.onRestart();
		setStatus("onRestart");
	}

	@Override
	protected void onResume() {
		super.onResume();
		setStatus("onResume");
	}

	@Override
	protected void onStart() {
		super.onStart();
		setStatus("onStart");
	}

	@Override
	protected void onStop() {
		super.onStop();

		setStatus("onStop");
		SharedPreferences oSettings = getSharedPreferences("screen_msg", 0);
		SharedPreferences.Editor oEdit = oSettings.edit();
		oEdit.putString("screen_msg", sStatus);
		oEdit.commit();

	}

}