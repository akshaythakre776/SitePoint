package tushinsky.alex.lesson5_ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class Spinner_Example extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.spinner_example);

		String[] items = new String[] { "TextView", "Button", "RadioButton",
				"Spinner", "CheckBox", "EditText", "WebView" };

		final Spinner oDropDown = (Spinner) findViewById(R.id.spinner01);

		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, items);
		
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		oDropDown.setAdapter(adapter);

		final Button btn1 = (Button) this.findViewById(R.id.btnSpinOK);

		btn1.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				final TextView tOut = (TextView) findViewById(R.id.txtSpinOut);
				String sText = "";

				sText = "Selected Item Text: " + oDropDown.getSelectedItem()
						+ "\n" + "Index: "
						+ oDropDown.getSelectedItemPosition() + "\n";

				tOut.setText(sText);

			}
		});

	}

}
