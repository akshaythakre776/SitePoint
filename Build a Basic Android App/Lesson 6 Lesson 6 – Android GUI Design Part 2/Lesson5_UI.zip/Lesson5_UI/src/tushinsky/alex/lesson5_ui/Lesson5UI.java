package tushinsky.alex.lesson5_ui;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Lesson5UI extends ListActivity {

	String[] GUIExamples = { "Buttons", // 0
			"EditText and TextView", // 1
			"Checkbox and RadioButtons", // 2
			"Spinner (Dropdown)", // 3
			"WebView", // 4
			"Other Layouts" // 5
	};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		setListAdapter(new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, GUIExamples));

	}

	public void onListItemClick(ListView parent, View v, int position, long id) {

		switch (position) {
		case 0: // Buttons
			startActivity(new Intent(this, Button_Example.class));
			break;
		case 1: // EditText / TextView
			startActivity(new Intent(this, EditText_Example.class));
			break;
		case 2: // Checkbox / Radiobutton
			startActivity(new Intent(this, Checkbox_Radio_Example.class));
			break;
		case 3: // Spinner
			startActivity(new Intent(this, Spinner_Example.class));
			break;
		case 4: // WebView
			startActivity(new Intent(this, WebView_Example.class));
			break;	
		case 5: // Other Layouts
			startActivity(new Intent(this, Other_Layouts_Example.class));
			break;				
		}

	}

}