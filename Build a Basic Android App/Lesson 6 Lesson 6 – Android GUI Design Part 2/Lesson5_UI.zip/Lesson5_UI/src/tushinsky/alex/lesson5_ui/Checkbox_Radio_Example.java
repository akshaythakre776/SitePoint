package tushinsky.alex.lesson5_ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class Checkbox_Radio_Example extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.checkbox_radio_example);

		final Button btn1 = (Button) this.findViewById(R.id.btnCheckOK);
		final ToggleButton btnToggle = (ToggleButton) findViewById(R.id.btnToggle);
		final CheckBox chk02 = (CheckBox) findViewById(R.id.chk02);
		final RadioButton rb01 = (RadioButton) findViewById(R.id.rd01);
		final RadioButton rb03 = (RadioButton) findViewById(R.id.rd03);
		final CheckBox chk01 = (CheckBox) findViewById(R.id.chk01);

		chk02.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Toast.makeText(
						getApplicationContext(),
						"Check #2 is "
								+ (chk02.isChecked() ? "checked"
										: "not checked") + "!",
						Toast.LENGTH_SHORT).show();
			}
		});

		btn1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {

				final TextView txtOut = (TextView) findViewById(R.id.txtCheckOut);
				String sText = "";

				if (rb01.isChecked()) {
					sText = "Group 1, Button 1 is selected\n";
				} else {
					sText += "Group 1, Button 2 is selected\n";
				}

				if (rb03.isChecked()) {
					sText += "Group 2, Button 1 is selected\n";
				} else {
					sText += "Group 2, Button 2 is selected\n";
				}

				if (chk01.isChecked()) {
					sText += "Check # 1 is selected\n";
				} else {
					sText += "Check # 1 is not selected\n";
				}

				if (chk02.isChecked()) {
					sText += "Check # 2 is selected\n";
				} else {
					sText += "Check # 2 is not selected\n";
				}

				if (btnToggle.isChecked()) {
					sText += "Toggle Button is selected\n";
				} else {
					sText += "Toggle Button is not selected\n";
				}

				txtOut.setText(sText);
			}
		});

	}

}
