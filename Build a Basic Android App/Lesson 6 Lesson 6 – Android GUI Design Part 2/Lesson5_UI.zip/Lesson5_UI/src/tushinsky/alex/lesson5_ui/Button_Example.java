package tushinsky.alex.lesson5_ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Button_Example extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.button_example);

		final Button btn1 = (Button) this.findViewById(R.id.Button01);
		final Button btn2 = (Button) this.findViewById(R.id.Button02);
		final Button btn3 = (Button) this.findViewById(R.id.Button03);
		final Button btn4 = (Button) this.findViewById(R.id.Button04);

		btn1.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Toast.makeText(getApplicationContext(), "Clicked Button # 1",
						Toast.LENGTH_SHORT).show();
			}
		});
		
		btn2.setFocusable(false);
		btn2.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Toast.makeText(getApplicationContext(), "Clicked Button # 2",
						Toast.LENGTH_SHORT).show();
			}
		});

		btn3.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Toast.makeText(getApplicationContext(), "Clicked Button # 3",
						Toast.LENGTH_SHORT).show();
			}
		});

		btn4.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Toast.makeText(getApplicationContext(), "Clicked Button # 4",
						Toast.LENGTH_SHORT).show();

			}
		});
		btn4.setOnFocusChangeListener(new View.OnFocusChangeListener() {

			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				if (hasFocus) {
					Toast.makeText(getApplicationContext(), "Has Focus",
							Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(getApplicationContext(), "Lost Focus",
							Toast.LENGTH_SHORT).show();
				}
			}
		});
		btn4.setOnLongClickListener(new View.OnLongClickListener() {

			@Override
			public boolean onLongClick(View v) {
				Toast.makeText(getApplicationContext(),
						"Long Press Button # 4", Toast.LENGTH_SHORT).show();
				return false;
			}
		});

	}

}
