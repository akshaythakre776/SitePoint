package tushinsky.alex.lesson5_ui;

import android.app.Activity;
import android.os.Bundle;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.Toast;

public class Other_Layouts_Example extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.other_layouts_example);

		final RatingBar oRate = (RatingBar) findViewById(R.id.ratingBar1);
		final SeekBar oSeek = (SeekBar) findViewById(R.id.seekBar1);

		oRate.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

			@Override
			public void onRatingChanged(RatingBar ratingBar, float rating,
					boolean fromUser) {
				Toast.makeText(
						getApplicationContext(),
						"SeekBar value = " + oSeek.getProgress() + "\n"
								+ "Rating is: " + oRate.getRating(),
						Toast.LENGTH_SHORT).show();

			}
		});

	}

}
