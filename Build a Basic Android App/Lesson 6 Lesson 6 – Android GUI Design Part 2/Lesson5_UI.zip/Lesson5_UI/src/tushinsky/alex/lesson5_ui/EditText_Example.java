package tushinsky.alex.lesson5_ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class EditText_Example extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.edittext_example);

		final Button btn1 = (Button) this.findViewById(R.id.btnTextOK);

		btn1.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {

				final EditText txtNum = (EditText) findViewById(R.id.txtNumOnly);
				final EditText txtMulti = (EditText) findViewById(R.id.txtMulti);
				final EditText txtPhone = (EditText) findViewById(R.id.txtPhone);
				final TextView txtOut = (TextView) findViewById(R.id.txtTextOut);

				String sText = "";

				sText = "txtNum = " + txtNum.getText() + "\n";
				sText += "txtMulti = " + txtMulti.getText() + "\n";
				sText += "txtPhone = " + txtPhone.getText() + "\n";

				txtOut.setText(sText);

			}
		});


	}

}
